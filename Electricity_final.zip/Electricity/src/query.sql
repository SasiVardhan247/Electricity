drop table login;
drop table bill;
drop table complaint;
drop table bills;
drop table payment;
drop table customer;
-------------------------------

select * from customer;
select * from login;

CREATE TABLE customer (
    consumerNumber BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1000000000001, INCREMENT BY 1) PRIMARY KEY, 
    customerId BIGINT UNIQUE NOT NULL, 
    title VARCHAR(10) NOT NULL,
    customerName VARCHAR(50) NOT NULL,
    email VARCHAR(30) UNIQUE NOT NULL,
    mobileNumber VARCHAR(15) NOT NULL,
    userId VARCHAR(20) UNIQUE NOT NULL,
    password VARCHAR(25) NOT NULL,
    customerStatus VARCHAR(10) DEFAULT 'Active' CHECK (customerStatus IN ('Active', 'Inactive'))
);


CREATE TABLE login (
    consumerNumber BIGINT PRIMARY KEY, 
    email VARCHAR(30) UNIQUE NOT NULL,
    userId VARCHAR(30) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    userType VARCHAR(10) NOT NULL CHECK (userType IN ('Customer', 'Admin')),
    userStatus VARCHAR(10) DEFAULT 'Active' CHECK (userStatus IN ('Active', 'Inactive')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);

CREATE TABLE bills (
    billNumber INT PRIMARY KEY,
    consumerNumber BIGINT,
    billUploadDate DATE,
    dueAmount DOUBLE,
    payableAmount DOUBLE,
    paymentId VARCHAR(8),
    paymentDate DATE,
    payment_status VARCHAR(10) CHECK (payment_status IN ('Paid', 'Unpaid')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);


CREATE TABLE complaint (
    complaintId INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 10001, INCREMENT BY 1) PRIMARY KEY,
    consumerNumber BIGINT NOT NULL,
    complaintType VARCHAR(50),
    category VARCHAR(50),
    customerName VARCHAR(50),
    landmark VARCHAR(100),
    problemDescription VARCHAR(250),
    mobileNumber VARCHAR(15),
    address VARCHAR(100),
    complaintStatus VARCHAR(15) DEFAULT 'Open' CHECK (complaintStatus IN ('Open', 'In Progress', 'Closed')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);

-----------------------------------------------------------------------------------------------------------------------
CREATE TABLE bill (
    billId INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY,
    consumerNumber BIGINT NOT NULL,
    billNumber INT UNIQUE NOT NULL,
    dueAmount DECIMAL(10,2) NOT NULL,
    payableAmount DECIMAL(10,2) NOT NULL,
    totalAmount DECIMAL(10,2) NOT NULL,
    billStatus VARCHAR(10) DEFAULT 'Unpaid' CHECK (billStatus IN ('Paid', 'Unpaid')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);

CREATE TABLE payment (
    paymentId INT GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY,
    consumerNumber BIGINT NOT NULL,
    cardNumber VARCHAR(16) NOT NULL,
    cardHolder VARCHAR(50) NOT NULL,
    expiryMonth VARCHAR(2) NOT NULL,
    expiryYear VARCHAR(4) NOT NULL,
    cvv VARCHAR(3) NOT NULL,
    totalAmount DECIMAL(10,2) NOT NULL,
    paymentMode VARCHAR(10) NOT NULL,
    transactionDate TIMESTAMP NOT NULL,
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);

INSERT INTO customer (customerId, title, customerName, email, mobileNumber, userId, password)
VALUES (20001, 'Mr.', 'ashu', 'admin@gmail.com', '9876543211', 'admin', '1234');

INSERT INTO LOGIN (consumerNumber, email, userId, password, userType) 
values (1000000000101,'admin@gmail.com','admin','1234','Admin');
