package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AdminComplaintDAO;

/**
 * Servlet implementation class ComplaintResolvedServlet
 */
@WebServlet("/ComplaintResolvedServlet")
public class ComplaintResolvedServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
   
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int complaintId = Integer.parseInt(request.getParameter("id"));
        
        AdminComplaintDAO complaintDAO=new AdminComplaintDAO();
        try {
            
            int isUpdated = complaintDAO.updateComplaintStatus(complaintId);
            
            if(isUpdated > 0)
            {
                request.setAttribute("updated", "Successfully Resolved!");
                response.sendRedirect("complaintManagement.jsp");
            }
            else
            {
                request.setAttribute("notUpdated", "Not updated/Already Resolved.");
                response.sendRedirect("complaintManagement.jsp");
            }
            
        } catch (SQLException e) {
            
            e.printStackTrace();
        }
    }

    
}