package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Customer;


public class AdminCustomerDAO {
	public boolean isEmailExist(String email) throws SQLException, ClassNotFoundException {
        String query = "SELECT email FROM Login WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        }
    }

	
    public boolean registerCustomer(Customer customer) throws SQLException, ClassNotFoundException {
        if (isEmailExist(customer.getEmail())) {
            throw new SQLException("Email already exists.");
        }

//        String insertCustomer = "INSERT INTO Customer (name, email, mobile) VALUES (?, ?, ?)";
        String insertCustomer = "INSERT INTO customer (customerId, title,customerName,email,mobileNumber,userId ,password,customerStatus) VALUES (?, ?,?,?,?,?,?,'Active')";
        String insertLogin = "INSERT INTO login (consumerNumber, email,userId, password, userType,userStatus) VALUES (?, ?, ? ,? ,'Customer', 'Active')";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement custStmt = conn.prepareStatement(insertCustomer);
             PreparedStatement loginStmt = conn.prepareStatement(insertLogin)) {

            long id=customer.getCustomerId();
//            int bill=customer.getBillNumber();
            String title=customer.getTitle();
            String name=customer.getCustomerName();
            String email=customer.getEmail();
            String mobile=customer.getMobileNumber();
            String userId=customer.getUserId();
            String pass=customer.getPassword();
            
           
            custStmt.setLong(1, id);
//            custStmt.setInt(2, bill);
            custStmt.setString(2, title);
            custStmt.setString(3, name);
            custStmt.setString(4, email );
            custStmt.setString(5, mobile);
            custStmt.setString(6, userId);
            custStmt.setString(7, pass);
            
            
            
            custStmt.executeUpdate();
            
            long  consumerNumber=0;
    		String que="select consumerNumber from customer where customerId=?";
            
    		PreparedStatement stm = conn.prepareStatement(que);
			stm.setLong(1, id);
			
			ResultSet rs= stm.executeQuery();
			
			if(rs.next())
			{
				 consumerNumber = rs.getLong("consumerNumber");
			}
            
            loginStmt.setLong(1, consumerNumber);
            loginStmt.setString(2, email);
            loginStmt.setString(3, userId); 
            loginStmt.setString(4, pass);
            
            loginStmt.executeUpdate();

           
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    

	public boolean updateCustomer(Customer c) throws ClassNotFoundException, SQLException
	{
		String sql = "UPDATE customer SET title=?,customerName=?, email=?,mobileNumber=?,userId=?,password=? where consumerNumber=?";
		
		String sql1 = "select * from customer where email=? and consumerNumber != ?";
		
		Connection con = DBConnection.getConnection();
		
		PreparedStatement pst1 = con.prepareStatement(sql1);
		pst1.setString(1, c.getEmail());
		pst1.setLong(2, c.getConsumerNumber());
		
		ResultSet rs = pst1.executeQuery();
		
		if(rs.next())
		{
			return false;
		}
		
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setString(1, c.getTitle());
		pst.setString(2, c.getCustomerName());
		pst.setString(3, c.getEmail());
		pst.setString(4, c.getMobileNumber());
		pst.setString(5, c.getUserId());
		pst.setString(6, c.getPassword());
		pst.setLong(7, c.getConsumerNumber());
		
		int count = pst.executeUpdate();
		
		return count>0;
		
		
	}

	public boolean deleteCustomer(long consumerNum) throws ClassNotFoundException, SQLException
	{
		String sql = "DELETE FROM customer WHERE consumerNumber = ?";
		String sql2="delete from login where consumerNumber=?";
		String sql3 ="delete from complaint where consumerNumber=?";
		
		
		Connection con = DBConnection.getConnection();
		
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setLong(1, consumerNum);
		
		PreparedStatement pstLogin = con.prepareStatement(sql2);
		pstLogin.setLong(1, consumerNum);
		
		PreparedStatement pstComplaint = con.prepareStatement(sql3);
		pstComplaint.setLong(1, consumerNum);
		
		int isDelete= pstComplaint.executeUpdate();
		int isDel = pstLogin.executeUpdate();
		int isDeleted = pst.executeUpdate();
		
		
		return true;
	}
	
	public ArrayList<Customer> viewCustomer() 
	{
		String sql = "SELECT * FROM customer";
		
		Connection con=null;
		
		ArrayList<Customer> list = new ArrayList<>();
		
		try {
			con = DBConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			//customerId, title,customerName,email,mobileNumber,userId ,password,customerStatus
			
			while(rs.next())
			{
				Customer c = new Customer();
				c.setCustomerId(rs.getLong("customerId"));
				c.setConsumerNumber(rs.getLong("consumerNumber"));
				c.setTitle(rs.getString("title"));
				c.setCustomerName(rs.getString("customerName"));
				c.setEmail(rs.getString("email"));
				c.setMobileNumber(rs.getString("mobileNumber"));
				c.setUserId(rs.getString("userId"));
				
				if(!c.getCustomerName().equalsIgnoreCase("admin")) {
					list.add(c);
				}
			}
			
			rs.close();
			pst.close();
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return list;
		
	}

	

	public Customer searchEdit(long consumerNumber) {
		String sql ="SELECT * FROM Customer WHERE consumerNumber=?";
		
		Connection con=null;
		Customer c=null;
		try {
			con = DBConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setLong(1, consumerNumber);
			
			ResultSet rs = pst.executeQuery();
			//String customerID, int billNumber, String title, String customerName, String email, String mobileNumber,
			//String userId, String password, String confirmPassword
			if(rs.next())
			{
				c=new Customer();
				//c.setCustomerID(rs.getString("customerId"));
				c.setTitle(rs.getString("title"));
				c.setCustomerName(rs.getString("customerName"));
				c.setEmail(rs.getString("email"));
				c.setMobileNumber(rs.getString("mobileNumber"));
				c.setUserId(rs.getString("userId"));
				c.setPassword(rs.getString("password"));
				c.setConsumerNumber(rs.getLong("consumerNumber"));			
			}
			
			rs.close();
			pst.close();
			con.close();
			
			return c;
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return c;
		
	}
	
	public Customer searchById(long consumerNumber) {
		String sql ="SELECT * FROM Customer WHERE consumerNumber=?";
		
		Connection con=null;
		Customer c=null;
		try {
			con = DBConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setLong(1, consumerNumber);
			
			ResultSet rs = pst.executeQuery();
			//String customerID, int billNumber, String title, String customerName, String email, String mobileNumber,
			//String userId, String password, String confirmPassword
			if(rs.next())
			{
				c=new Customer();
				c.setCustomerId(rs.getLong("customerId"));
				c.setTitle(rs.getString("title"));
				c.setCustomerName(rs.getString("customerName"));
				c.setEmail(rs.getString("email"));
				c.setMobileNumber(rs.getString("mobileNumber"));
				c.setUserId(rs.getString("userId"));
				c.setPassword(rs.getString("password"));
//				c.setConfirmPassword(rs.getString("confirmPassword"));
			}
			
			rs.close();
			pst.close();
			con.close();
			
			return c;
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return c;
		
	}


	public Customer validateUser(String userId, String password) {
		// TODO Auto-generated method stub
		
		Customer customer = null;
        String query = "SELECT consumerNumber FROM login WHERE userId = ? AND password = ?";

        try{
        	Connection conn = DBConnection.getConnection();

        	PreparedStatement ps = conn.prepareStatement(query);
        	
        	
            ps.setString(1, userId);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                long consumerNumber = rs.getLong("consumerNumber");

                // Fetch full customer details from customer table
                
                customer = getCustomerByConsumerNumber(consumerNumber);
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return customer;

	}
	
	public Customer getCustomerByConsumerNumber(long consumerNumber) throws SQLException {
        Customer customer = null;
        String query = "SELECT * FROM customer WHERE consumerNumber = ?";
        
        Connection conn = DBConnection.getConnection();

        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setLong(1, consumerNumber);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    customer = new Customer();
                    customer.setConsumerNumber(rs.getLong("consumerNumber"));
                    customer.setCustomerId(rs.getLong("customerId"));
                    customer.setTitle(rs.getString("title"));
                    customer.setCustomerName(rs.getString("customerName"));
                    customer.setEmail(rs.getString("email"));
                    customer.setMobileNumber(rs.getString("mobileNumber"));
                    customer.setUserId(rs.getString("userId"));
                    customer.setPassword(rs.getString("password"));
                    customer.setCustomerStatus(rs.getString("customerStatus"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return customer;
    }


	

}


