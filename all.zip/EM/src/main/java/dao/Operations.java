package dao;

import java.util.*;
import java.sql.*;
import model.Bills;

public class Operations {
	private static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	private static final String URL = "jdbc:derby:C:\\Users\\sahil\\MyDB;create=true";

	public static ArrayList<Bills> viewBill(long consumerID) {
		System.out.println("OPERATIONS -> 12 ->"+consumerID);
		ArrayList<Bills> bills = new ArrayList<>();
		try {
			Class.forName(DRIVER);
			try (Connection conn = DriverManager.getConnection(URL);
					PreparedStatement stmt = conn.prepareStatement(
							"SELECT * FROM BILLS WHERE consumerNumber = ?  ORDER BY billUploadDate DESC")) {

				stmt.setLong(1, consumerID);
				ResultSet rs = stmt.executeQuery();

				while (rs.next()) {
					Bills bill = new Bills();
					bill.setBillNumber(rs.getInt("billNumber"));
					bill.setConsumerNumber(rs.getLong("consumerNumber"));
					bill.setBillUploadDate(rs.getDate("billUploadDate"));
					bill.setDueAmount(rs.getDouble("dueAmount"));
					bill.setPayableAmount(rs.getDouble("payableAmount"));
					bill.setPaymentId(rs.getString("paymentId"));
					bill.setPaymentDate(rs.getDate("PaymentDate"));
					bill.setPaymentStatus(rs.getString("payment_status"));
					bills.add(bill);
				}
			}
		} catch (Exception e) {
			System.out.println("Error in viewBill: " + e.getMessage());
			e.printStackTrace();
		}
		return bills;
	}

	public double getAmount(String billnumber) {
		try {
			Class.forName(DRIVER);
			Connection con = DriverManager.getConnection(URL);
			String sql = "select * from bills where billNumber = ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, billnumber);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int bill = rs.getInt(1);
				return bill;

			}
			rs.close();
			stmt.close();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;
	}

	public void updateBill(int billNumber, double amount, String paymentId) {
		try {
			Class.forName(DRIVER);
			Connection con = DriverManager.getConnection(URL);
			String sql = "UPDATE bills SET payment_status = 'Paid', PaymentDate = ?, paymentId = ? WHERE billNumber = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setDate(1, new java.sql.Date(System.currentTimeMillis()));
			pst.setString(2, paymentId);
			pst.setInt(3, billNumber);
			pst.executeUpdate();
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public long getConsumerNumber(int billNumber) {
		long consumerNumber = 0;
		try {
			Class.forName(DRIVER);
			try (Connection conn = DriverManager.getConnection(URL);
					PreparedStatement stmt = conn.prepareStatement(
							"SELECT consumerNumber FROM bills WHERE billNumber = ?")) {

				stmt.setInt(1, billNumber);
				ResultSet rs = stmt.executeQuery();
				if (rs.next()) {
					consumerNumber = rs.getLong("consumerNumber");
				}
			}
		} catch (Exception e) {
			System.out.println("Error in getConsumerNumber: " + e.getMessage());
			e.printStackTrace();
		}
		return consumerNumber;
	}

}
