package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Bill;
import model.Bills;
import model.Customer;

public class AdminBillDAO {
    private static Connection conn;
    AdminCustomerDAO customerDAO = new AdminCustomerDAO();


    public Bill getBillsByConsumerNumber(long consumerNumber) {
        Bill bills = null;
        String query = "SELECT * FROM bills WHERE consumerNumber = ?";
        conn = DBConnection.getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setLong(1, consumerNumber);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Bill bill = new Bill();
                
                bill.setConsumerNumber(rs.getLong("consumerNumber"));
                bill.setBillNumber(rs.getInt("billNumber"));
                bill.setDueAmount(rs.getDouble("dueAmount"));
                bill.setPayableAmount(rs.getDouble("payableAmount"));
                
              
          
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bills;
    }

  
    //Fetch a single bill by its ID
    public Bills getBillById(int billId) {
        Bills bill = null;
        String query = "SELECT * FROM bill WHERE billNumber = ?";
        conn = DBConnection.getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, billId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                bill = new Bills();
                bill.setConsumerNumber(rs.getLong("consumerNumber"));
                bill.setBillNumber(rs.getInt("billNumber"));
                bill.setDueAmount(rs.getDouble("dueAmount"));
                bill.setPayableAmount(rs.getDouble("payableAmount"));
                bill.setPaymentStatus(rs.getString("payment_status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bill;
    }
    
    //Fetch a single bill by its ID
    public Bills getBillByBillNum(int billNum) {
        Bills bill = null;
        String query = "SELECT * FROM bills WHERE billNumber = ?";
        conn = DBConnection.getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, billNum);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                bill = new Bills();
                bill.setBillNumber(rs.getInt("billNumber"));
                bill.setConsumerNumber(rs.getLong("consumerNumber"));
//                bill.setBillNumber(rs.getInt("billNumber"));
                bill.setDueAmount(rs.getDouble("dueAmount"));
                bill.setPayableAmount(rs.getDouble("payableAmount"));
                bill.setPaymentStatus(rs.getString("payment_status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bill;
    }

    /**
     * Add a new bill to the database
     * @throws SQLException 
     */
    public boolean addBill(Bills bill) throws SQLException {
        String query = "INSERT INTO bills (billNumber,consumerNumber, billUploadDate, dueAmount, payableAmount, paymentId,paymentDate ,payment_status) VALUES (?, ?, ?, ?, ?, ?,?,?)";

        conn = DBConnection.getConnection();
        
        Customer c = customerDAO.getCustomerByConsumerNumber(bill.getConsumerNumber());
        
        System.out.println(c.getConsumerNumber());
        if(c != null)
        {
        	try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            	pstmt.setInt(1, bill.getBillNumber());
                pstmt.setLong(2, bill.getConsumerNumber());
                pstmt.setDate(3, bill.getBillUploadDate());
                pstmt.setDouble(4, bill.getDueAmount());
                pstmt.setDouble(5, bill.getPayableAmount());
                pstmt.setString(6, bill.getPaymentId());
                pstmt.setDate(7, bill.getPaymentDate());
                pstmt.setString(8, bill.getPaymentStatus());

                int rowsInserted = pstmt.executeUpdate();
                return rowsInserted > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }

    /**
     * Update an existing bill
     */
    public boolean updateBill(Bills bill) {
        String query = "UPDATE bills SET dueAmount = ?, payableAmount = ?,  payment_status = ? WHERE billNumber = ?";
        conn = DBConnection.getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, bill.getDueAmount());
            pstmt.setDouble(2, bill.getPayableAmount());
            pstmt.setString(3, bill.getPaymentStatus());
            pstmt.setInt(4, bill.getBillNumber());

            int rowsUpdated = pstmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Delete a bill by ID
     */
    public  boolean deleteBill(int billId) {
        String query = "DELETE FROM bills WHERE billNumber = ?";
        conn = DBConnection.getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, billId);
            int rowsDeleted = pstmt.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Mark a bill as paid
     */
    public  boolean markBillAsPaid(int billId) {
        String query = "UPDATE bill SET payableAmount = 0, billStatus = 'Paid' WHERE billId = ?";
        conn = DBConnection.getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, billId);
            int rowsUpdated = pstmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Retrieve all unpaid bills for a consumer
     */
    public  static  List<Bill> getUnpaidBills(long consumerNumber) {
        List<Bill> unpaidBills = new ArrayList<>();
        String query = "SELECT * FROM bill WHERE consumerNumber = ? AND billStatus = 'Pending'";
        conn = DBConnection.getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setLong(1, consumerNumber);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Bill bill = new Bill();
                bill.setBillId(rs.getInt("billId"));
                bill.setConsumerNumber(rs.getLong("consumerNumber"));
                bill.setBillNumber(rs.getInt("billNumber"));
                bill.setDueAmount(rs.getDouble("dueAmount"));
                bill.setPayableAmount(rs.getDouble("payableAmount"));
                bill.setTotalAmount(rs.getDouble("totalAmount"));
                bill.setBillStatus(rs.getString("billStatus"));
                unpaidBills.add(bill);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return unpaidBills;
    }
    
    
    public int getBillNumber()
    {
    	int billNumber=1000;
    	
Connection conn=null;
    	conn = DBConnection.getConnection();
    	
    	Statement stmt;
    	
		try{
			
			stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT MAX(billNumber) FROM bills");
	        
			if (rs.next()) {
	             billNumber = rs.getInt(1) + 1;
	        }
			
			rs.close();
			stmt.close();
			conn.close();
			
		}catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		if(billNumber <= 1)
		{
			billNumber = 1000;
		}
 
    	return billNumber;
    }
    
    public ArrayList<Bills> getBills()
    {
    	ArrayList<Bills> list=new ArrayList<>();
    	Bills b=null;
    	
    	Connection conn = DBConnection.getConnection();
    	
    	String sql= "select * from Bills";
    	
    	try {
			PreparedStatement pst = conn.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
				b=new Bills();
				b.setBillNumber(rs.getInt("billNumber"));
				b.setConsumerNumber(rs.getLong("consumerNumber"));
				b.setDueAmount(rs.getDouble("dueAmount"));
				b.setPayableAmount(rs.getDouble("payableAmount"));
				//billNumber,consumerNumber, billUploadDate, dueAmount, payableAmount, paymentId,paymentDate ,billStatus
				b.setBillUploadDate((rs.getDate("billUploadDate")));
				b.setPaymentStatus(rs.getString("payment_status"));
				
				list.add(b);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	
    	
    	
    	return list;
    }
    
    
}


