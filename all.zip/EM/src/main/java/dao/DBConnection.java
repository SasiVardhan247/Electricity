package dao;

import java.sql.*;

//import org.apache.derby.jdbc.EmbeddedDriver;

public class DBConnection {
 public static Connection getConnection() {
     Connection connection = null;
     try {
    	 Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
//    	 connection = DriverManager.getConnection("jdbc:derby:D:\\Users\\2830988\\MyDB;create=true");
    	 connection = DriverManager.getConnection("jdbc:derby:C:\\Users\\sahil\\MyDB;create=true");
    	 
     } catch (ClassNotFoundException | SQLException e) {
    	 System.out.println("DBCONNECTION -> "+e.getMessage());
         e.printStackTrace();
     }
     return connection;
 }
 
}

