package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import dao.AdminCustomerDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteCustomerServlet
 */
@WebServlet("/DeleteCustomerServlet")
public class AdminDeleteCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
	        throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		long consumerNumber = Long.parseLong(request.getParameter("id"));
		
		AdminCustomerDAO custDAO = new AdminCustomerDAO();
		
		try {
			boolean isDeleted = custDAO.deleteCustomer(consumerNumber);
			
			
			if(isDeleted)
			{
				response.sendRedirect("customerManagement.jsp");
			}
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
	}

}



