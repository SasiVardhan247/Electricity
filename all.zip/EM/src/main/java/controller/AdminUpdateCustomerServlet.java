package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import dao.AdminCustomerDAO;
//import com.ebill.utility.RandomIdGenerator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Customer;

/**
 * Servlet implementation class UpdateCustomerServlet
 */
@WebServlet("/AdminUpdateCustomerServlet")
public class AdminUpdateCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	        throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		long consumerNumber= Long.parseLong(request.getParameter("id"));
		String title= request.getParameter("title");
        String customerName = request.getParameter("customerName");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("mobileNumber");
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");
        
        
        Customer c = new Customer();
        
        c.setConsumerNumber(consumerNumber);
        c.setCustomerName(customerName);
        c.setTitle(title);
        c.setEmail(email);
        c.setMobileNumber(mobileNumber);
        c.setUserId(userId);
        c.setPassword(password);
        
        
        AdminCustomerDAO custDAO = new AdminCustomerDAO();
        
        try {
			boolean isUpdated = custDAO.updateCustomer(c);
			
			if(isUpdated)
			{
				out.println("Updated Successfully!");
				
				response.sendRedirect("customerManagement.jsp");
			}
			else
			{
				
				response.sendRedirect("error.jsp?error=\"Email Already Exists or SQL Error");   
			}
		} catch (ClassNotFoundException e) {
			out.println(e);
			//e.printStackTrace();
		} catch (SQLException e) {
			out.println(e);
			//e.printStackTrace();
		}
        
        
	}

}



