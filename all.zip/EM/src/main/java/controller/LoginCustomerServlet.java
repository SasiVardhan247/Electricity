package controller;

import java.io.IOException;
import java.sql.Connection;

import dao.CustomerDAO;
import dao.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Customer;

@WebServlet("/LoginCustomer")
public class LoginCustomerServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private CustomerDAO customerDAO;

    @Override
    public void init() throws ServletException {
        try {
            Connection conn = DBConnection.getConnection(); 
            customerDAO = new CustomerDAO(conn);
   
        } catch (Exception e) {
            throw new ServletException("Database connection error", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");

        try {
        	System.out.println("validating the details");
            Customer customer = customerDAO.validateUser(userId, password);
            
            if (customer != null) {
                if ("active".equalsIgnoreCase(customer.getCustomerStatus())) {
                    // Start session and redirect to home page
                    HttpSession session = request.getSession();
                    
                    if(session != null)
                    {
                    	session.invalidate();
                    }
                    
                    session = request.getSession(true);
                    
                    if(customer.getUserId().equalsIgnoreCase("admin"))
                    {
                    	
                    	session.setAttribute("adminCustomer", customer);
                    	
                    	
                    }
                    else
                    {
                    	
                    	session.setAttribute("customer", customer);
                    }
                    String userType = customerDAO.getUserType(customer.getConsumerNumber());
                    if ("Admin".equalsIgnoreCase(userType)) {
                        response.sendRedirect("adminHome.jsp");
                    } else { 
                    	response.sendRedirect("home.jsp");
                    }
                    
                } else {
                    response.sendRedirect("login.jsp?inactive=true&userId="+userId);
                }
            } else {
                response.sendRedirect("login.jsp?message=Invalid User ID or Password.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp?message=Something went wrong! Please try again.");
        }
    }
}