package controller;



import java.io.IOException;

//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

import dao.AdminCustomerDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Customer;

import java.sql.Connection;
import java.util.Random;

@WebServlet("/AdminAddCustomer")
public class AdminAddCustomer extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AdminCustomerDAO customerDAO;

    public static long generateCustomerId() {
        long timestampPart = System.currentTimeMillis() / 100;  // Get first 11 digits
        Random random = new Random();
        int randomPart = random.nextInt(100);  // Generate a 2-digit random number
        return (timestampPart * 100) + randomPart;  // Combine timestamp + random
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
           
            String title = request.getParameter("title");
            String customerName = request.getParameter("customerName");
            String email = request.getParameter("email");
            String mobileNumber = request.getParameter("mobileNumber");
            String userId = request.getParameter("userId");
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmPassword");

            // Validate password match
            if (!password.equals(confirmPassword)) {
                request.setAttribute("error", "Passwords do not match!");
                request.getRequestDispatcher("adminAddCustomer.jsp").forward(request, response);
                return;
            }
            
            long customerId=generateCustomerId();
            
            	
            Customer customer = new Customer(customerId, title, customerName, email, mobileNumber, userId, password);

            // Register customer
            customerDAO = new AdminCustomerDAO();
            boolean isRegistered = customerDAO.registerCustomer(customer);

            if (isRegistered) {
                // Pass customer details to the acknowledgment page
                request.setAttribute("registeredCustomer", customer);
                request.getRequestDispatcher("AdminRegisterAcknowledgement.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Registration failed! Try again.");
                request.getRequestDispatcher("adminAddCustomer.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred during registration!");
            request.getRequestDispatcher("adminAddCustomer.jsp").forward(request, response);
        }
    }
}