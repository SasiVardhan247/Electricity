package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Date;





import dao.AdminBillDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Bills;

@WebServlet("/AdminAddBillServlet")
public class AdminAddBillServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int billNumber = Integer.parseInt(request.getParameter("billNumber"));
        long consumerNumber = Long.parseLong( request.getParameter("consumerNumber"));
        double dueAmount = Double.parseDouble(request.getParameter("dueAmount"));
        double payableAmount = Double.parseDouble(request.getParameter("payableAmount"));
//        Date uploadDate = new Date();
        Date uploadDate=new Date(System.currentTimeMillis());
       
       
       
        // Validate that payableAmount is not greater than dueAmount
        if (payableAmount > dueAmount) {
            response.sendRedirect("addBill.jsp?invalid=1");
            return;
        }

        try {
           
        	Bills b = new Bills(billNumber,consumerNumber,uploadDate,dueAmount,payableAmount,null,null,"Unpaid");
        	
        	
        	AdminBillDAO billDAO = new AdminBillDAO();
        	boolean isAdd = billDAO.addBill(b);
        	
        	if(isAdd)
        	{
        		response.sendRedirect("billManagement.jsp");
        	}
        	else
        	{
        		
        		 response.sendRedirect("error.jsp?error=Consumer Number / Customer Not Found");   
        	}
        	
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?error=Consumer Number / Customer Not Found");
        }
    }
}


