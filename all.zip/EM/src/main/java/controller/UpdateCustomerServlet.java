package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dao.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Customer;

@WebServlet("/UpdateCustomerServlet")
public class UpdateCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("customer") == null) {
            response.sendRedirect("login.jsp?message=Please login first.");
            return;
        }

        // Retrieve customer session
        Customer customer = (Customer) session.getAttribute("customer");
        String userId = customer.getUserId();
        

        // Get updated values from form
        String title = request.getParameter("title").trim();
        String customerName = request.getParameter("customerName").trim();
        String mobileNumber = request.getParameter("mobileNumber").trim();
        String email = request.getParameter("email").trim();

        try (Connection conn = DBConnection.getConnection()) {
        	// Check if email already exists for another user
        	String checkEmailSql = "SELECT userId FROM Customer WHERE email = ? AND userId != ?";
        	try (PreparedStatement checkStmt = conn.prepareStatement(checkEmailSql)){
        		checkStmt.setString(1, email);
        		checkStmt.setString(2, userId);
        		ResultSet rs = checkStmt.executeQuery();
        		
        		if(rs.next()) {
        			response.sendRedirect("updateCustomer.jsp?error=Email already exists. Choose another.");
        			return;
        		}
        		
        	}
        	
        	
            String sql = "UPDATE Customer SET title = ?, customerName = ?, mobileNumber = ?, email = ? WHERE userId = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, title);
                stmt.setString(2, customerName);
                stmt.setString(3, mobileNumber);
                stmt.setString(4, email);
                stmt.setString(5, userId);

                int rowsUpdated = stmt.executeUpdate();

                if (rowsUpdated > 0) {
                    // Update session data with new values
                    customer.setTitle(title);
                    customer.setCustomerName(customerName);
                    customer.setMobileNumber(mobileNumber);
                    session.setAttribute("customer", customer);

                    response.sendRedirect("ViewCustomerServlet?success=true");
                } else {
                    response.sendRedirect("updateCustomer.jsp?error=Update failed.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("updateCustomer.jsp?error=Database error.");
        }
    }
}
