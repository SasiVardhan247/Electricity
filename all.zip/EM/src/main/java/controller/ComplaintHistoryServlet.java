package controller;

import java.io.IOException;
import java.util.ArrayList;

import dao.ComplaintDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Complaint;
import model.Customer;

@WebServlet("/ComplaintHistoryServlet")
public class ComplaintHistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	HttpSession session = req.getSession();
    	
    	Customer customer = (Customer) session.getAttribute("customer");
        if (customer == null) {
            req.setAttribute("errorMessage", "Session expired. Please log in again.");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
            return;
        }
    	
        Long consumerNumber = customer.getConsumerNumber();
        ArrayList<Complaint> complaintList = ComplaintDAO.getComplaintsByCustomerId(consumerNumber);      
        req.setAttribute("complaints", complaintList);

        RequestDispatcher dispatcher = req.getRequestDispatcher("complaint_history1.jsp");
        dispatcher.forward(req, resp);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
