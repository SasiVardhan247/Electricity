package controller;


import java.io.IOException;
import java.sql.SQLException;

import dao.AdminComplaintDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Complaint;

@WebServlet("/AdminRegisterComplaint")
public class AdminRegisterComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // Get form parameters
        String complaintType = req.getParameter("complaintType");
        String category = req.getParameter("category");
        String landmark = req.getParameter("landmark").trim();
        String problemDes = req.getParameter("problemDes").trim();
        String mobileNumber = req.getParameter("mobileNumber");
        String address = req.getParameter("address").trim();
        long consumerNumber= Long.parseLong(req.getParameter("consumerNumber"));
        String contactPerson = req.getParameter("contactPerson").trim();
        String status = "Open";

        if(landmark.length()<2  || problemDes.length()<2 || address.length()<2 || contactPerson.length()<2 ) {
        	req.setAttribute("error", "invalid fields");
            req.getRequestDispatcher("AdminAddComplaint.jsp").forward(req, resp);
            return;
        }
        // Create a Complaint object
        Complaint complaint = new Complaint( complaintType, category, contactPerson, landmark, consumerNumber, problemDes, mobileNumber, address, status);

        // Register the complaint
        int result=0;
		try {
			result = AdminComplaintDAO.registerComplaint(complaint);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
        System.out.println("Complaint created");
        if (result > 0) {
        	resp.sendRedirect("complaintManagement.jsp");
            
        } else {     
            resp.sendRedirect("error.jsp?error=Sorry! Unable to save the complaint/Consumer Number Not Found. Please try again.");
        }
    }
}


