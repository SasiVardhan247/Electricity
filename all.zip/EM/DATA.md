Complaint Type: Billing Related
Category: Wrong Bill
Contact Person: Rajesh Sharma
Landmark: Near City Mall
Problem Description: Received an unusually high bill even though consumption was normal.
Mobile Number: 9876543210
Address: 12/3, Shiv Nagar, Jaipur

Complaint Type: Voltage Related
Category: Low Voltage
Contact Person: Anita Verma
Landmark: Behind SBI Bank
Problem Description: Voltage is too low to operate basic appliances.
Mobile Number: 9988776655
Address: 45, Green Park, Delhi

Complaint Type: Frequent Disruption
Category: Power Cut
Contact Person: Manoj Kumar
Landmark: Near Metro Station
Problem Description: Daily power cuts for 3-4 hours without prior notice.
Mobile Number: 9898989898
Address: Flat 202, Sunrise Apartments, Pune

Complaint Type: Street Light Related
Category: Light Not Working
Contact Person: Seema Yadav
Landmark: Opposite Govt School
Problem Description: Street light not functioning for 2 weeks, area is dark at night.
Mobile Number: 9123456789
Address: Sector 12, Noida

Complaint Type: Pole Related
Category: Leaning Pole
Contact Person: Dinesh Patel
Landmark: Beside Krishna Temple
Problem Description: Electric pole is leaning dangerously towards the road.
Mobile Number: 9090909090
Address: 78, Naya Bazar, Bhopal

Complaint Type: Billing Related
Category: Meter Reading Issue
Contact Person: Pooja Mehra
Landmark: Near Railway Crossing
Problem Description: Meter reading recorded incorrectly this month.
Mobile Number: 9823456781
Address: 34/A, Gandhi Nagar, Ahmedabad

Complaint Type: Voltage Related
Category: Voltage Fluctuations
Contact Person: Akash Jain
Landmark: Opp. Community Hall
Problem Description: Heavy voltage fluctuations damaging appliances.
Mobile Number: 9845612378
Address: 5, Rajendra Colony, Indore

Complaint Type: Frequent Disruption
Category: Transformer Issue
Contact Person: Sunita Rathi
Landmark: Near Bus Depot
Problem Description: Transformer sparks and emits sound, unsafe.
Mobile Number: 9765432180
Address: Block C, Main Road, Ranchi

Complaint Type: Street Light Related
Category: Damaged Pole
Contact Person: Vikram Singh
Landmark: Near Hospital Gate
Problem Description: Pole holding the street light is rusted and about to fall.
Mobile Number: 9812233445
Address: 11, Jawahar Path, Lucknow

Complaint Type: Pole Related
Category: Broken Pole
Contact Person: Neha Kulkarni
Landmark: Beside Petrol Pump
Problem Description: Electric pole is broken into two pieces. Needs immediate fix.
Mobile Number: 9834456677
Address: Gokul Road, Hubli




/// CUSTOMER
Title: Mr.
Name: Rajesh Kumar
Email: rajesh.kumar@example.com
Mobile Number: +91 9876543210
User ID: raj_kumar10
Password: Raj@1234
Confirm Password: Raj@1234

Title: Mrs.
Name: Sunita Verma
Email: sunita.verma@example.com
Mobile Number: +91 9123456780
User ID: sunitaV_88
Password: Sunita@2024
Confirm Password: Sunita@2024

Title: Mr.
Name: Amit Sharma
Email: amit.sharma@example.com
Mobile Number: +91 9988776655
User ID: amitS99
Password: Amit#99pass
Confirm Password: Amit#99pass

Title: Ms.
Name: Pooja Rani
Email: pooja.rani@example.com
Mobile Number: +91 7766554433
User ID: pooja_rani12
Password: Pooja@12#
Confirm Password: Pooja@12#

Title: Mr.
Name: Deepak Yadav
Email: deepak.y@example.com
Mobile Number: +91 9090909090
User ID: deepakyadav90
Password: Deepak@123
Confirm Password: Deepak@123

Title: Dr.
Name: Nidhi Bansal
Email: nidhi.bansal@example.com
Mobile Number: +91 8899776655
User ID: drnidhi
Password: Nidhi#Dr2024
Confirm Password: Nidhi#Dr2024

Title: Mr.
Name: Arjun Singh
Email: arjun.singh@example.com
Mobile Number: +91 9988998899
User ID: arjuns123
Password: Arjun@Pass1
Confirm Password: Arjun@Pass1

Title: Ms.
Name: Neha Kapoor
Email: neha.kapoor@example.com
Mobile Number: +91 7888997766
User ID: nehakap_22
Password: Neha@Kap22
Confirm Password: Neha@Kap22

Title: Mr.
Name: Vikram Chauhan
Email: vikram.c@example.com
Mobile Number: +91 9812345678
User ID: vikramchauhan
Password: Vik@2024
Confirm Password: Vik@2024

Title: Mrs.
Name: Meena Sharma
Email: meena.sharma@example.com
Mobile Number: +91 9123987654
User ID: meenasharma12
Password: Meena@12
Confirm Password: Meena@12




