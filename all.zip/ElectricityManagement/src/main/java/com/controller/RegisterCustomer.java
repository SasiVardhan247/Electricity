package com.controller;

import java.io.IOException;
import java.sql.Connection;



import com.dao.CustomerDAO;
import com.entity.Customer;
import com.helper.DBHelper;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/registerCustomer")
public class RegisterCustomer extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private com.dao.CustomerDAO customerDAO;
    public RegisterCustomer() {
        super();
        this.customerDAO=new CustomerDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
       
            String title = request.getParameter("title");
            String customerName = request.getParameter("customerName").trim();
            String email = request.getParameter("email").trim();
            String mobileNumber = request.getParameter("mobileNumber");
            String userId = request.getParameter("userId").trim();
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmPassword");


            // Check if email or user ID already exists
            if (customerDAO.isEmailOrUserIdExists(email, userId)) {
                request.setAttribute("error", "Email or User ID already exists!");
                request.getRequestDispatcher("register.jsp").forward(request, response);
                return;
            }
            
            
 
            long customerId = CustomerDAO.generateCustomerId();

     
            Customer customer = new Customer(customerId, title, customerName, email, mobileNumber, userId, password);

            boolean isRegistered = customerDAO.registerCustomer(customer);

            if (isRegistered) {

                request.setAttribute("registeredCustomer", customer);
                request.getRequestDispatcher("registerAcknowledgement.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Registration failed! Try again.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred during registration!");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
        finally {
        	DBHelper.close();
        }
    }
}