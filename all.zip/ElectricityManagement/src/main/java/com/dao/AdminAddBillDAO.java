package com.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.helper.*;

import com.dao.*;
import com.entity.*;

public class AdminAddBillDAO {

	 private String insert = "INSERT INTO bills (billNumber,consumerNumber, billUploadDate, dueAmount, payableAmount, paymentId,paymentDate ,payment_status) VALUES (?, ?, ?, ?, ?, ?,?,?)";

	
	
	 //
	 public boolean addBill(Bills bill) throws SQLException {
//		 PreparedStatement preparedStatement=DBHelper.getPreparedStatement(insert);

	        
//	        Customer c = customerDAO.getCustomerByConsumerNumber(bill.getConsumerNumber());
//	        
//	        System.out.println(c.getConsumerNumber());
//	        if(c != null)
//	        {
//	        	try (PreparedStatement pstmt = conn.prepareStatement(query)) {
//	            	pstmt.setInt(1, bill.getBillNumber());
//	                pstmt.setLong(2, bill.getConsumerNumber());
//	                pstmt.setDate(3, bill.getBillUploadDate());
//	                pstmt.setDouble(4, bill.getDueAmount());
//	                pstmt.setDouble(5, bill.getPayableAmount());
//	                pstmt.setString(6, bill.getPaymentId());
//	                pstmt.setDate(7, bill.getPaymentDate());
//	                pstmt.setString(8, bill.getPaymentStatus());
//
//	                int rowsInserted = pstmt.executeUpdate();
//	                return rowsInserted > 0;
//	            } catch (SQLException e) {
//	                e.printStackTrace();
//	            }
//	        }

	        return false;
	    }
	
	
}
