package com.tcs.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tcs.entity.Car;
import com.tcs.helper.DBHelper;
import com.tcs.model.CarDAO;

public class CarController {
   private CarDAO carDAO;
   
   public CarController() {
	   this.carDAO= new CarDAO();
   }
   
   
   //INSERT
    public String insert(Car car) {
    	String output="";
    	try {
			int numberOfRecords=this.carDAO.insert(car);
			output= "INSERTED SUCCESSFULLY!";
		} catch (SQLException |ClassNotFoundException e) {
			output= "SOME ERROR OCCURED"+e.getMessage();
		}
    	finally {
    		DBHelper.close();
    	}
    	return output;
    }
    
    
  //UPDATE
    public String update(Car car) {
    	String output="";
    	try {
			int numberOfRecords=this.carDAO.update(car);
			output= numberOfRecords+" of records are updated";
		} catch (SQLException |ClassNotFoundException e) {
			output="SOME ERROR OCCURED"+e.getMessage();
		}finally {
			DBHelper.close();
		}
    	
    	return output;
    }
	
    
    
    //DELETED
    public String delete(int id) {
        String output="";
    	try {
			int numberOfRecords=this.carDAO.delete(id);
			output=numberOfRecords+" of records are Deleted";
		} catch (SQLException |ClassNotFoundException e) {
			output="SOME ERROR OCCURED"+e.getMessage();
		}
    	finally {
    		DBHelper.close();
    	}
    	return output;
    }
    
    
    //VIEW
    public List<Car> view() {
      List<Car> cars=new ArrayList<Car>();
      try {
			cars= this.carDAO.view();
		} catch (SQLException |ClassNotFoundException e) {
			 cars=new ArrayList<Car>(); 
		}
       finally {
    	   DBHelper.close();
       }
      return cars;
    }
    
    
    
	
	
}
