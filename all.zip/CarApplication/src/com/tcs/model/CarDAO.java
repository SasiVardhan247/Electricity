package com.tcs.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tcs.entity.Car;
import com.tcs.helper.DBHelper;

public class CarDAO {
	
	String in="insert into car values(?,?,?)";
	String up="update car set name=? where id=?";
	String del="delete from car where id=?";
	String sel="select * from car";
	
	public int insert(Car car) throws ClassNotFoundException, SQLException {
		PreparedStatement preparedStatement=DBHelper.getPreparedStatement(in);
		
		preparedStatement.setInt(1, car.getId());
		preparedStatement.setString(2, car.getName());
		preparedStatement.setInt(3, car.getSpeed());
		
		int noOfRecordsAffected=preparedStatement.executeUpdate();
		
		return noOfRecordsAffected;
	}
	
	public int update(Car car) throws ClassNotFoundException, SQLException {
		
		PreparedStatement preparedStatement=DBHelper.getPreparedStatement(up);
	    int id=car.getId();
	    String name=car.getName();
	
		preparedStatement.setString(1,name);
		preparedStatement.setInt(2, id);
		
        int noOfRecordsAffected=preparedStatement.executeUpdate();
		
		return noOfRecordsAffected;
		
	}
	
	
    public int delete(int id) throws ClassNotFoundException, SQLException {
		
		PreparedStatement preparedStatement=DBHelper.getPreparedStatement(del);
		
		preparedStatement.setInt(1, id);
		
        int noOfRecordsAffected=preparedStatement.executeUpdate();
		
		return noOfRecordsAffected;
		
	}
    
    public  List<Car> view() throws ClassNotFoundException, SQLException {
    	List<Car> cars=new ArrayList<>();
		System.out.println("CAR DAO -> VIEW ");
  		PreparedStatement preparedStatement=DBHelper.getPreparedStatement(sel);
  		
        ResultSet rs=preparedStatement.executeQuery();
  		
  		
  			while (rs.next()) {
			    int id=rs.getInt("id");
			    String name= rs.getString("name");
			    int speed=rs.getInt("speed") ;
			
			    
			    Car car=new Car(id,name,speed);
		
			    car.toString();
			    cars.add(car);
			}
  		
  		
  		return cars;
  		
  	}
  	
	
	
	

}
