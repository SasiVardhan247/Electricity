package com.tcs.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

final public class DBHelper {
	private static Connection connection;
	private static PreparedStatement preparedStatement;
	
	public static PreparedStatement getPreparedStatement(String sql) throws ClassNotFoundException,SQLException{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		DBHelper.connection=DriverManager.getConnection("jdbc:derby:C:\\Users\\sahil\\MyDB;create=true");
		DBHelper.preparedStatement=DBHelper.connection.prepareStatement(sql);
		return DBHelper.preparedStatement;
	}
	
	public static void close() {
		try {
			DBHelper.preparedStatement.close();
			DBHelper.connection.close();
			System.out.println(" DBHELPER -> CLOSE -> CONNECTION CLOSED");
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	

}
