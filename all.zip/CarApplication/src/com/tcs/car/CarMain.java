package com.tcs.car;

import java.sql.SQLException;
import java.util.List;

import com.tcs.controller.CarController;
import com.tcs.entity.Car;
import com.tcs.helper.DBHelper;
import com.tcs.model.CarDAO;

public class CarMain {
	public static void main(String[] args) {
		 Car car = new Car(4, "Car5", 404);
		 
		 CarController carController=new CarController();
		 
		 String output=carController.update(car);
		 System.out.println("CARMAIN -> INSERT -> "+output);

         System.out.println("CAR MAIN -> SELECT -> ");
         for(Car car1: carController.view()) {
        	 System.out.println(car1.toString());
         }
		 
		 
//		 insert(car);
//		 select();
		 
		
	        
	}

}
