/**
 * 
 */
/**
 * 
 */
module CarApplication {
	requires java.sql;
}