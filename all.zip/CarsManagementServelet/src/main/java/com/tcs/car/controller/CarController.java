package com.tcs.car.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import com.tcs.car.entity.Car;
import com.tcs.car.model.CarDAO;

@WebServlet({"/CarController","/car"})
public class CarController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    private CarDAO carDao;
    public CarController() {
        super();
        this.carDao=new CarDAO();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<Car> cars=this.carDao.view();
			System.out.println(cars);
			
			PrintWriter out=response.getWriter();
			out.println("<table border=2>");
			
			out.println("<tr>");
			out.println("<th>Id<th>");
			out.println("<th>Name<th>");		
			out.println("<th>Speed<th>");
			out.println("</tr>");
			
			for(Car car: cars) {
				out.println("<tr>");
				out.println("<td>"+ car.getId() +"<td>");
				out.println("<td>"+ car.getName()+"<td>");		
				out.println("<td>"+ car.getSpeed() +"<td>");
				out.println("</tr>");
			}
	
			out.println("</table>");
			out.println("<a href='insert.html'> Click here to go insert page</a>");
			out.println("<a href='update.html'> Click here to go update page</a>");
			out.println("<a href='delete.html'> Click here to go delete page</a>");
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			response.getWriter().print("SOME ERRO OCCURED  -> "+e.getMessage());
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getParameter("action");
		try {
		if(action==null) {
			response.sendRedirect("car");
		}
		else {
			if(action.equalsIgnoreCase("insert")) {
				int carId=Integer.parseInt(request.getParameter("id"));
				String name=request.getParameter("name");
				int speed=Integer.parseInt(request.getParameter("speed"));
				
				Car car=new Car(carId, name, speed);
				this.carDao.insert(car);
				
			}
			if(action.equalsIgnoreCase("update")) {
				int carId=Integer.parseInt(request.getParameter("id"));
				String name=request.getParameter("name");
				int speed=Integer.parseInt(request.getParameter("speed"));
				
				Car car=new Car(carId, name, speed);
				this.carDao.update(car);
				
			}
			if(action.equalsIgnoreCase("delete")) {
				int carId=Integer.parseInt(request.getParameter("id"));
				
				this.carDao.delete(carId);
				
			}
		}
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		response.sendRedirect("car");

	
	}

}
