package com.tcs.car.entity;
import java.sql.Date;

public class Bills {
	private int billNumber;
	private long consumerNumber;
	private Date billUploadDate;
	private double dueAmount;
	private double payableAmount;
	private String paymentId;
	private Date paymentDate;
	private String paymentStatus;

	// Default constructor
	public Bills() {}

	// Constructor with all fields
	public Bills(int billNumber, long consumerNumber, Date billUploadDate, 
				double dueAmount, double payableAmount, String paymentId, 
				Date paymentDate, String paymentStatus) {
		this.billNumber = billNumber;
		this.consumerNumber = consumerNumber;
		this.billUploadDate = billUploadDate;
		this.dueAmount = dueAmount;
		this.payableAmount = payableAmount;
		this.paymentId = paymentId;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
	}

	// Getters and Setters
	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public long getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(long consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	public Date getBillUploadDate() {
		return billUploadDate;
	}

	public void setBillUploadDate(Date billUploadDate) {
		this.billUploadDate = billUploadDate;
	}

	public double getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(double dueAmount) {
		this.dueAmount = dueAmount;
	}

	public double getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(double payableAmount) {
		this.payableAmount = payableAmount;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@Override
	public String toString() {
		return "Bill{" +
				"billNumber=" + billNumber +
				", consumerNumber=" + consumerNumber +
				", billUploadDate=" + billUploadDate +
				", dueAmount=" + dueAmount +
				", payableAmount=" + payableAmount +
				", paymentId='" + paymentId + '\'' +
				", paymentDate=" + paymentDate +
				", paymentStatus='" + paymentStatus + '\'' +
				'}';
	}
}