package com.tcs.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class TestingServlet1
 */
@WebServlet("/TestingServlet1")
public class TestingServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public TestingServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("GET IS CALLED");
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("TS1 -> POST IS CALLED");
		PrintWriter out= response.getWriter();
		String userId=request.getParameter("userid");
		String password=request.getParameter("password");
		
		if(userId.equals("sahil") && password.equals("admin")) {
			System.out.println("TS1 ->  ADMIN IS CALLED "+userId +"  p="+password);
			
//			
//			
//			RequestDispatcher requestDispatcher=request.getRequestDispatcher("test");
//			requestDispatcher.include(request, response);
//			requestDispatcher.include(request, response);
			
			
			HttpSession session=request.getSession();
			session.setAttribute("userId",userId);	
			response.sendRedirect("test");
			

//			
			response.getWriter().append("\nAFTER SERVLET 1 ");
		}
		else {
			response.getWriter().print("USER IS CALLED");
		}
//		doGet(request, response);
	}

}
