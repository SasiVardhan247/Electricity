package com.tcs.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(value= {"/test","/temp"})
public class TestingServlet2  extends HttpServlet{
	private static final long serialVersionUID = 1L;

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("TESTIING SERVLET 2-> GET");
		String userId=(String) request.getSession().getAttribute("userId");
		
		response.getWriter().append("USER ID="+userId);
	
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("TESTIING SERVLET 2-> POST");
		
//		String userId=(String) request.getSession().getAttribute("userId");
		
		
//		String userId=request.getParameter("userid");
//		String password=request.getParameter("password");
//		response.sendRedirect("index.html");
		response.getWriter().append("SERVLET 2 userid = ");
	
	}

}
