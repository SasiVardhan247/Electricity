package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.AdminBillDAO;
import model.Bills;

/**
 * Servlet implementation class UpdateBillServlet
 */
@WebServlet("/AdminUpdateBillServlet")
public class AdminUpdateBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	        throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		//int billId= Integer.parseInt(request.getParameter("id"));
		int billNumber= Integer.parseInt(request.getParameter("billNumber"));
        double dueAmount = Double.parseDouble(request.getParameter("dueAmount"));
        double payableAmount = Double.parseDouble(request.getParameter("payableAmount"));
        String billStatus = request.getParameter("billStatus");
        
        Bills b = new Bills();
       
        b.setBillNumber(billNumber);
        b.setDueAmount(dueAmount);
        b.setPayableAmount(payableAmount);
        b.setPaymentStatus(billStatus);       
        
        AdminBillDAO billDAO = new AdminBillDAO();
        
        boolean isUpdated = billDAO.updateBill(b);
		
		if(isUpdated)
		{
			out.println("Updated Successfully!");
			
			response.sendRedirect("billManagement.jsp");
		}
		else
		{
			out.println("Not Updated/ No bill Number Found.");
		}
        
        
	}


}

