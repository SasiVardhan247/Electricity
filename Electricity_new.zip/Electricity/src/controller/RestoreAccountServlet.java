package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.DBConnection;

@WebServlet("/RestoreAccountServlet")
public class RestoreAccountServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String userId = request.getParameter("userId");

        try (Connection conn = DBConnection.getConnection()) {
            
            // Update customer table
            String updateCustomerSQL ="UPDATE Login SET userStatus = 'Active' WHERE userId = ?";
            PreparedStatement customerStmt = conn.prepareStatement(updateCustomerSQL);
            customerStmt.setString(1, userId);
            int customerRows = customerStmt.executeUpdate();
            customerStmt.close();

            // Update login table
            String updateLoginSQL = "UPDATE Customer SET customerStatus = 'Active' WHERE userId = ?";
            PreparedStatement loginStmt = conn.prepareStatement(updateLoginSQL);
            loginStmt.setString(1, userId);
            int loginRows = loginStmt.executeUpdate();
            loginStmt.close();

            if (customerRows > 0 && loginRows > 0) {
                conn.commit(); // Commit transaction
                response.sendRedirect("login.jsp?restored=true");
            } else {
                conn.rollback(); // Roll back if update fails
                response.sendRedirect("login.jsp?message=Error restoring account.");
                
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp?message=Database error.");
        }
    }
}