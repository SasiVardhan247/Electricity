package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Complaint;
import model.Customer;


public class AdminComplaintDAO {
	public static AdminCustomerDAO customerDAO = new AdminCustomerDAO();
	
	public static int registerComplaint(Complaint c) throws ClassNotFoundException, SQLException {
		//createComplaintTable();
		
		
		String sql = "INSERT INTO Complaint(complaintType,category,landmark,customerName,problemDescription,consumerNumber,address,mobileNumber)"
				+ " VALUES(?,?,?,?,?,?,?,?)";
		
		Customer cus = customerDAO.getCustomerByConsumerNumber(c.getConsumerNumber());
		
		if(cus == null)
		{
			return 0;
		}
		
		Connection con = DBConnection.getConnection();
		
		System.out.println("Got conn"+con);
		
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setString(1,  c.getComplaintType());
		pst.setString(2, c.getCategory());
		pst.setString(3, c.getLandmark());
		pst.setString(4, c.getCustomerName());
		pst.setString(5, c.getProblem());
		pst.setLong(6, c.getConsumerNumber());
		pst.setString(7, c.getAddress());
		pst.setString(8, c.getMobileNumber()+"");
		
		 int rows = pst.executeUpdate();
		
//		System.out.println("Working   2 ");
		
		pst.close();
		con.close();
		
		return rows;
	}
	public void createComplaintTable() throws ClassNotFoundException, SQLException
	{
		System.out.println("Create");
		
		String sql ="create table IF NOT EXISTS Complaint"
				+ "( complaintType varchar(50) not null, "
				+ "category varchar(50) not null,"
				+ "landmark varchar(50) ,"
				+ " customerName varchar(50) not null,"
				+ "problem varchar(100)  not null, "
				+ "consumerNumber int not null,"
				+ "address varchar(100) not null,"
				+ "mobileNumber varchar(15) not null)";
		
		
		Connection con = DBConnection.getConnection();
		
		if(con != null)
		{
			System.out.println("Established");
		}
		Statement stmt = con.createStatement();
		stmt.execute(sql);
		
		System.out.println("Working  1 ");
		
		stmt.close();
		con.close();
	}

	public boolean deleteComplaint(int complaintId){
		String sql = "DELETE FROM Complaint WHERE complaintId = ?";
		
		Connection con = DBConnection.getConnection();
		
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
	            pstmt.setInt(1, complaintId);
	            int rowsDeleted = pstmt.executeUpdate();
	            return rowsDeleted > 0;
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	        return false;
	    }

	public Complaint searchComplaint(int complaintId) throws ClassNotFoundException, SQLException {
		Complaint c=null;
		String sql ="SELECT * FROM complaint WHERE complaintId =?";
		
		Connection con = DBConnection.getConnection();
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setInt(1, complaintId);
		
		ResultSet rs = pst.executeQuery();
		
		if(rs.next())
		{
		     c = new Complaint();
			c.setComplaintId(rs.getInt("complaintId"));
			c.setConsumerNumber(rs.getLong("consumerNumber"));
			c.setComplaintType(rs.getString("complaintType"));
			c.setCategory(rs.getString("category"));
			c.setCustomerName(rs.getString("customerName"));
			c.setLandmark(rs.getString("landmark"));
			c.setProblem(rs.getString("problemDescription"));
			c.setMobileNumber(rs.getString("mobileNumber"));
			c.setAddress(rs.getString("address"));
			c.setComplaintStatus(rs.getString("complaintStatus"));
			
		}
		
		return c;
	}
	
	
	public  ArrayList<Complaint> viewComplaint()
    {
    	String sql = "SELECT * FROM complaint";
		
		Connection con=null;
		
		ArrayList<Complaint> list = new ArrayList<>();
		
		try {
			con = DBConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			//customerId, title,customerName,email,mobileNumber,userId ,password,customerStatus
			
			while(rs.next())
			{
				Complaint c = new Complaint();
				c.setComplaintId(rs.getInt("complaintId"));
				c.setConsumerNumber(rs.getLong("consumerNumber"));
				c.setComplaintType(rs.getString("complaintType"));
				c.setCategory(rs.getString("category"));
				c.setCustomerName(rs.getString("customerName"));
				c.setLandmark(rs.getString("landmark"));
				c.setProblem(rs.getString("problemDescription"));
				c.setMobileNumber(rs.getString("mobileNumber"));
				c.setAddress(rs.getString("address"));
				c.setComplaintStatus(rs.getString("complaintStatus"));
				

				//list.add(c);
				System.out.println(rs.getString("complaintStatus"));

				if(!rs.getString("complaintStatus").trim().equalsIgnoreCase("Closed"))
				{
					list.add(c);
				}
			}
			
			rs.close();
			pst.close();
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return list;
    }


	public int updateComplaintStatus(int complaintId) throws SQLException {
		int isUpdated =0;
		
		String sql="update complaint set complaintStatus = 'Closed' where complaintId=?";
		
		Connection con = DBConnection.getConnection();
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setInt(1, complaintId);
		
		isUpdated = pst.executeUpdate();
		
		pst.close();
		con.close();
		
		return isUpdated;
	}
 
 
	

}
