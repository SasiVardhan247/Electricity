package controller;

import java.io.IOException;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Customer;
import dao.Operations;

@WebServlet(name = "EbillServlet", urlPatterns = { "/ebill" }, loadOnStartup = 1)
public class EbillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			HttpSession session = request.getSession();
			Customer customer = (Customer) session.getAttribute("customer");
			if (customer == null) {
				response.sendRedirect("login.jsp");
				return;
			}

			String operation = request.getParameter("operation");
			System.out.println("Operation received: " + operation);

			switch (operation) {
				case "initiate_payment":
					handleInitiatePayment(request, response, session);
					break;

				case "select_payment_method":
					handlePaymentMethod(request, response, session);
					break;

				case "finish":
					handlePaymentFinish(request, response, session);
					break;

				default:
					response.sendRedirect("viewBill.jsp");
					break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error in EbillServlet: " + e.getMessage());
			response.sendRedirect("error.jsp");
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	private void handleInitiatePayment(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws ServletException, IOException {

		System.out.println("Handling initiate payment");

		String[] selectedBills = request.getParameterValues("selectedBills");
		if (selectedBills == null || selectedBills.length == 0) {
			System.out.println("No bills selected");
			response.sendRedirect("viewBill.jsp");
			return;
		}

		ArrayList<ArrayList<String>> data = new ArrayList<>();
		for (int i = 0; i < selectedBills.length; i++) {
			if (selectedBills[i].contains("selectedBills"))
				continue;

			ArrayList<String> billInfo = new ArrayList<>();
			billInfo.add(selectedBills[i]); // Amount
			String billNumber = request.getParameter("selectedBills " + selectedBills[i]);
			billInfo.add(billNumber);
			data.add(billInfo);
			System.out.println("Added bill: Amount=" + selectedBills[i] + ", Number=" + billNumber);
		}

		session.setAttribute("paymentData", data);
		System.out.println("Data stored in session: " + data);

		try {
			System.out.println("Forwarding to payment.jsp");
			request.getRequestDispatcher("payment.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error forwarding to payment.jsp: " + e.getMessage());

		}
	}

	private void handlePaymentMethod(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws ServletException, IOException {

		String paymentMethod = request.getParameter("payment");

		String targetJsp = "credit".equals(paymentMethod) ? "/credit.jsp" : "/debit.jsp";
		request.getRequestDispatcher(targetJsp).forward(request, response);
	}

	private void handlePaymentFinish(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws ServletException, IOException {

		try {
			ArrayList<ArrayList<String>> data = (ArrayList<ArrayList<String>>) session.getAttribute("paymentData");

			Operations op = new Operations();
			for (ArrayList<String> bill : data) {
				String paymentId = generatePaymentId();
				double amount = Double.parseDouble(bill.get(0));
				int billNumber = Integer.parseInt(bill.get(1));
				long consumerNumber = op.getConsumerNumber(billNumber);

				op.updateBill(billNumber, amount, paymentId);

				request.setAttribute("list", data);
				request.setAttribute("consumerNumber", consumerNumber);
			}

			session.removeAttribute("paymentData");
			request.getRequestDispatcher("/paymentDone.jsp").forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
			response.sendRedirect("error.jsp");
		}
	}

	private String generatePaymentId() {
		return String.format("%03d%02d", System.currentTimeMillis() % 1000, new Random().nextInt(100));
	}
}