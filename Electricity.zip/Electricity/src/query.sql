drop table login;
drop table bill;
drop table complaint;
drop table bills;
drop table payment;
drop table customer;
-------------------------------

select * from customer;


CREATE TABLE customer (
    consumerNumber BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1000000000001, INCREMENT BY 1) PRIMARY KEY, 
    customerId BIGINT UNIQUE NOT NULL, 
    title VARCHAR(10) NOT NULL,
    customerName VARCHAR(50) NOT NULL,
    email VARCHAR(30) UNIQUE NOT NULL,
    mobileNumber VARCHAR(15) NOT NULL,
    userId VARCHAR(20) UNIQUE NOT NULL,
    password VARCHAR(25) NOT NULL,
    customerStatus VARCHAR(10) DEFAULT 'Active' CHECK (customerStatus IN ('Active', 'Inactive'))
);


CREATE TABLE login (
    consumerNumber BIGINT PRIMARY KEY, 
    email VARCHAR(30) UNIQUE NOT NULL,
    userId VARCHAR(30) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    userType VARCHAR(10) NOT NULL CHECK (userType IN ('Customer', 'Admin')),
    userStatus VARCHAR(10) DEFAULT 'Active' CHECK (userStatus IN ('Active', 'Inactive')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);

CREATE TABLE bills (
    billNumber INT PRIMARY KEY,
    consumerNumber BIGINT,
    billUploadDate DATE,
    dueAmount DOUBLE,
    payableAmount DOUBLE,
    paymentId VARCHAR(8),
    paymentDate DATE,
    payment_status VARCHAR(10) CHECK (payment_status IN ('Paid', 'Unpaid')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);


CREATE TABLE complaint (
    complaintId INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 10001, INCREMENT BY 1) PRIMARY KEY,
    consumerNumber BIGINT NOT NULL,
    complaintType VARCHAR(50),
    category VARCHAR(50),
    customerName VARCHAR(50),
    landmark VARCHAR(100),
    problemDescription VARCHAR(250),
    mobileNumber VARCHAR(15),
    address VARCHAR(100),
    complaintStatus VARCHAR(15) DEFAULT 'Open' CHECK (complaintStatus IN ('Open', 'In Progress', 'Closed')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);

-----------------------------------------------------------------------------------------------------------------------
CREATE TABLE bill (
    billId INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY,
    consumerNumber BIGINT NOT NULL,
    billNumber INT UNIQUE NOT NULL,
    dueAmount DECIMAL(10,2) NOT NULL,
    payableAmount DECIMAL(10,2) NOT NULL,
    totalAmount DECIMAL(10,2) NOT NULL,
    billStatus VARCHAR(10) DEFAULT 'Unpaid' CHECK (billStatus IN ('Paid', 'Unpaid')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);

CREATE TABLE payment (
    paymentId INT GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY,
    consumerNumber BIGINT NOT NULL,
    cardNumber VARCHAR(16) NOT NULL,
    cardHolder VARCHAR(50) NOT NULL,
    expiryMonth VARCHAR(2) NOT NULL,
    expiryYear VARCHAR(4) NOT NULL,
    cvv VARCHAR(3) NOT NULL,
    totalAmount DECIMAL(10,2) NOT NULL,
    paymentMode VARCHAR(10) NOT NULL,
    transactionDate TIMESTAMP NOT NULL,
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);



-- Insert Harshit into the customer table
INSERT INTO customer (customerId, title, customerName, email, mobileNumber, userId, password)
VALUES (20001, 'Mr.', 'Harshit', 'harshit@example.com', '9876543211', 'harshit', 'password');

-- Insert Harshit's login details into the login table
INSERT INTO login (consumerNumber, email, userId, password, userType)
VALUES (1000000000001,'harshit@example.com', 'harshit', 'password', 'Customer');

-- Insert at least five bill records for Harshit (mix of Paid and Unpaid)

-- Bill 1: Paid
INSERT INTO bill (consumerNumber, billNumber, dueAmount, payableAmount, totalAmount, billStatus)
VALUES (1000000000001, 6001, 500.00, 0.00, 500.00, 'Paid');








/*-- Bill 2: Unpaid
INSERT INTO bill (consumerNumber, billNumber, dueAmount, payableAmount, totalAmount, billStatus)
VALUES (1000000000002, 6002, 750.00, 750.00, 750.00, 'Unpaid');

-- Bill 3: Unpaid
INSERT INTO bill (consumerNumber, billNumber, dueAmount, payableAmount, totalAmount, billStatus)
VALUES (1000000000003, 6003, 300.00, 300.00, 300.00, 'Unpaid');

-- Bill 4: Paid
INSERT INTO bill (consumerNumber, billNumber, dueAmount, payableAmount, totalAmount, billStatus)
VALUES (1000000000004, 6004, 450.00, 0.00, 450.00, 'Paid');

-- Bill 5: Unpaid
INSERT INTO bill (consumerNumber, billNumber, dueAmount, payableAmount, totalAmount, billStatus)
VALUES (1000000000005, 6005, 600.00, 600.00, 600.00, 'Unpaid');*/

select * from customer;
select * from login;
select * from bill;
select * from complaint;


select * from CUSTOMER;
select * from LOGIN;
select * from bill;

CREATE TABLE bills (
    billNumber INT PRIMARY KEY,
    consumerNumber BIGINT,
    billUploadDate DATE,
    dueAmount DOUBLE,
    payableAmount DOUBLE,
    paymentId VARCHAR(8),
    paymentDate DATE,
    payment_status VARCHAR(10) CHECK (payment_status IN ('Paid', 'Unpaid')),
    FOREIGN KEY (consumerNumber) REFERENCES customer(consumerNumber)
);


INSERT INTO bills (
    billNumber, 
    consumerNumber, 
    billUploadDate, 
    dueAmount, 
    payableAmount, 
    paymentId, 
    paymentDate, 
    payment_status
) VALUES (
    101,                 -- Bill Number (must be unique)
    1000000000303,       -- Consumer Number (existing in customer table)
    CURRENT_DATE,        -- Bill Upload Date (Today's Date)
    1500.75,            -- Due Amount
    1400.50,            -- Payable Amount (After discount)
    'PAY12345',         -- Payment ID (Dummy value)
    NULL,               -- Payment Date (NULL if unpaid)
    'Unpaid'            -- Payment Status
);

INSERT INTO bills (
    billNumber, 
    consumerNumber, 
    billUploadDate, 
    dueAmount, 
    payableAmount, 
    paymentId, 
    paymentDate, 
    payment_status
) VALUES 
(102, 1000000000303, '2024-01-15', 2000.00, 1900.00, 'PAY67890', '2024-01-20', 'Paid'),
(103, 1000000000303, '2024-02-10', 2500.50, 2400.75, 'PAY23456', '2024-02-15', 'Paid'),
(104, 1000000000303, '2024-03-05', 1800.25, 1700.00, NULL, NULL, 'Unpaid'),
(105, 1000000000303, '2024-04-01', 3000.00, 2900.00, NULL, NULL, 'Unpaid'),
(106, 1000000000303, '2024-05-01', 2200.00, 2100.00, 'PAY45678', '2024-05-05', 'Paid');



